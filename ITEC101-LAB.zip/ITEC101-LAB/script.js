const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const confirmationMessage = document.getElementById("confirmationMessage");

taskForm.addEventListener("submit", function (e) {
  e.preventDefault();
  const task = taskInput.value.trim();
  if (task !== "") {
    
    // Save task to localStorage
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));

    // Show confirmation
    confirmationMessage.textContent = `Task "${task}" added.`;
    confirmationMessage.className = "message";

    taskInput.value = "";
    taskInput.focus();
  }
});
