const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const confirmationMessage = document.getElementById("confirmationMessage");

taskForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const task = taskInput.value.trim();
    if (task !== "") {
        const li = document.createElement("li");
        li.textContent = task;
        li.style.marginLeft = "20px"; // Adds space before each task
        taskList.appendChild(li);
        

        // Set green success message
        confirmationMessage.textContent = `Task "${task}" added.`;
        confirmationMessage.className = "message"; // make sure this class is defined in your CSS

        taskInput.value = "";
        taskInput.focus();

        
    }
});
