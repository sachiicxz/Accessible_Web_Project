<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Accessible To-Do List</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<style>
  nav {
    background-color: #1e3a8a;
    color: white;
    padding: 10px;
    text-align: center;
    margin-bottom: 5%;
  }

  ul li {
    margin-left: 20px;
    margin-top: 8px;
    color: green;
  }

  html,
  body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
  }

  #container {
    flex: 1;
  }

  .footer {
    background-color: #091e58;
    text-align: center;
    color: white;
  }

  .card {
        margin: 20px 0;
        background-color: #fafafa;

    }
  #container {
    max-width: 60%;
    margin: auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
  }

  .nav-link {
    color: white;
  }

  h3 {
    text-transform: uppercase;
  }
</style>

<body>

  <nav>
    <ul class="nav justify-content-center py-2">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="instructions.php">Instructions</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tasks.php">My Tasks</a>
      </li>
    </ul>
  </nav>

  <div class="container" id="container">

    <div class="card shadow mt-3 mb-3" id="myTasks">
      <div class="card-body">
        <h3 class="card-title mb-3 fw-bold text-center">To-Do List</h3>

        <hr>

        <ul id="savedTaskList"></ul>

        </h1>
      </div>
    </div>

    <script>
      const savedTaskList = document.getElementById("savedTaskList");
      const tasks = JSON.parse(localStorage.getItem("tasks")) || [];

      tasks.forEach(task => {
        const li = document.createElement("li");
        li.textContent = task;
        savedTaskList.appendChild(li);
      });
    </script>
  </div>

  <footer class="footer py-2">
    <p>&copy; 2025 Accessible Web Projects</p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>