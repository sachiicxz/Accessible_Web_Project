<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Accessible To-Do List</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<style>
    nav {
        background-color: #1e3a8a;
        color: white;
        padding: 10px;
        text-align: center;
        margin-bottom: 5%;
    }

    ul li {
        margin-left: 20px;
        margin-top: 8px;
        color: green;
    }

    html,
    body {
        height: 100%;
        margin: 0;
        display: flex;
        flex-direction: column;
    }

    #container {
        flex: 1;
    }

    .footer {
        background-color: #091e58;
        text-align: center;
        color: white;
    }

    #container {
        max-width: 60%;
        height: 100%;
        margin: auto;
        background-color: white;
        padding: 20px;
        border-radius: 8px;
    }

    .card {
        margin: 20px 0;
        background-color: #fafafa;

    }

    .nav-link {
        color: white;
    }

    h3 {
        text-transform: uppercase;
        text-align: center;
        font-weight: bold;
    }

    .card-body .card-text {
        text-align: center;
        font-size: 17px;
    }

    .list-unstyled li {
        color: black;
    }
</style>

<body>
    <nav>
        <ul class="nav justify-content-center py-2">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="instructions.php">Instructions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="tasks.php">My Tasks</a>
            </li>
        </ul>
    </nav>

    <div class="container" id="container">
        <div class="card shadow" id="instructions">
            <div class="card-body">
                <h3 class="card-title">Instructions</h3>
                <hr>
                <p class="card-text mt-5">
                    Use the form below to add tasks. Use the keyboard <b>(Tab & Enter)</b> to navigate and interact.
                    <br><br>

                    <strong>Keyboard Shortcuts:</strong><br>

                <ul class="list-unstyled">
                    <li><strong>Tab</strong>: Move to the next input field.</li>
                    <li><strong>Shift + Tab</strong>: Move to the previous input field.</li>
                    <li><strong>Enter</strong>: Submit the form.</li>
                    </p>
                </ul>
            </div>
        </div>
    </div>


    <footer class="footer py-2">
        <p>&copy; 2025 Accessible Web Projects</p>
    </footer>

</body>


</html>