<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Accessible To-Do List</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<style>
  nav {
    background-color: #1e3a8a;
    color: white;
    padding: 10px;
    text-align: center;
    margin-bottom: 5%;
  }

  ul li {
    margin-left: 20px;
    margin-top: 8px;
    color: green;
  }

  html,
  body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
  }

  #container {
    flex: 1;
  }

  .footer {
    background-color: #091e58;
    text-align: center;
    color: white;
  }

  #container {
    max-width: 60%;
    height: 100%;
    margin: auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
  }

  .card {
    margin: 20px 0;
    background-color: #fafafa;
  }

  .nav-link {
    color: white;
  }

  h3 {
    text-transform: uppercase;
    text-align: center;
    font-weight: bold;
  }

  .card-body .card-text {
    text-align: center;
    font-size: 17px;
  }

  .header h2 {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    text-transform: uppercase;
  }

  .message {
    margin-top: 10px;
    color: green;
    font-style: italic;
  }

  input[type="text"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    box-sizing: border-box;
    border: 2px solid #ccc;
  }

  .btn-add {
    padding: 10px;
    background-color: #1e3a8a;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
    border-radius: 5px;
    align-items: center;
    justify-content: center;
    display: flex;
    text-align: center;
  }
</style>

<body>

  <nav>
    <ul class="nav justify-content-center py-2 text-white">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="instructions.php">Instructions</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tasks.php">My Tasks</a>
      </li>
    </ul>
  </nav>


  <div class="header">
    <h2>Accessible To-Do List</h2>
  </div>

  <div class="container" id="container">

    <div class="card shadow mt-3 mb-3" id="myTasks">
      <div class="card-body">
        <h3 class="card-title mb-3 fw-bold">My Tasks</h3>

        <hr>

        <form id="taskForm" class="mb-3">
          <div class="mb-3">
            <label for="taskInput" class="form-label">Add New Task:</label>
            <input type="text" id="taskInput" class="form-control" required />
          </div>

          <div class="d-flex justify-content-center">
            <button type="submit" class="btn-add w-50">Add Task</button>
          </div>
        </form>

        <div id="confirmationMessage" class="message"></div>
      </div>
    </div>
  </div>

  <footer class="footer py-2">
    <p>&copy; 2025 Accessible Web Projects</p>
  </footer>

  <script src="script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>