<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Accessible To-Do List</title>

  <link rel="stylesheet" href="style.css">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

  <header class="header py-4" id="home">
    <div class="text-center">
      <h1 class="m-0">Accessible To-Do List</h1>
    </div>
  </header>

  <nav>
    <ul class="nav justify-content-center py-2">
      <li class="nav-item">
        <a class="nav-link" href="#home">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#instructions">Instructions</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#myTasks">My Tasks</a>
      </li>
    </ul>
  </nav>


  <div class="container" id="container">
    <div class="card shadow" id="instructions">
      <div class="card-body">
        <h5 class="card-title">Instructions</h5>
        <p class="card-text">
          Use the form below to add tasks. Use the keyboard (Tab, Enter) to navigate and interact.
        </p>
      </div>
    </div>


    <div class="card shadow mt-3 mb-3" id="myTasks">
      <div class="card-body">
        <h4 class="card-title mb-3 fw-bold">My Tasks</h4>
        <form id="taskForm" class="mb-3">
          <div class="mb-3">
            <label for="taskInput" class="form-label">Add New Task:</label>
            <input type="text" id="taskInput" class="form-control" required />
          </div>

          <div class="d-flex justify-content-center">
            <button type="submit" class="btn-add w-50">Add Task</button>
          </div>
        </form>

        <ul class="list-group mb-3" id="taskList"></ul>
        <ul id="taskList" class="mb-3"></ul>
        <div id="confirmationMessage" class="message"></div>
      </div>
    </div>
  </div>


  <footer class="footer py-2">
    <p>&copy; 2025 Accessible Web Projects</p>
  </footer>

  <script src="script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>